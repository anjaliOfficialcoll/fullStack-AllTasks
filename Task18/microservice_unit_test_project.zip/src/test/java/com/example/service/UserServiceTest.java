package com.example.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UserServiceTest {

    @Test
    void testGetUserName() {
        UserService service = new UserService();
        assertEquals("Anjali", service.getUserName(1));
        assertEquals("Unknown", service.getUserName(2));
    }
}
