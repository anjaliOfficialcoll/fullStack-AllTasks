package com.example.controller;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UserControllerTest {

    @Test
    void testController() {
        UserController controller = new UserController();
        assertEquals("Anjali", controller.getUser(1));
    }
}
